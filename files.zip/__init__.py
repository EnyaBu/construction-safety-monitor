"""
Tests Package
Unit tests for Construction Safety Monitor
"""
